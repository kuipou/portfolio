</div>
<footer class="main-footer">
      <section class="tag">&copy; Christophe Rudyj 1999-<? echo date('Y');?> Drawings of me by <a href="http://www.boumerie.com/">Boum</a></section>
      <aside class="social">
        <ul>
          <a href="https://twitter.com/kuipou"><li><i class="fa fa-twitter"></i></li></a>
          <a href="https://github.com/kuipou"><li><i class="fa fa-github"></i></li></a>
          <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
        </ul>
      </aside>
    </footer>
    <?php wp_footer(); ?>
  </body>
  </html>