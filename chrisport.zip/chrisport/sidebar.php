<aside class="sidebar">
      <ul>
        <li><a href="#">2011</a></li>
        <li><a href="#">2012</a></li>
        <li><a href="#">2013</a></li>
        <li><a href="#">2014</a></li>
      </ul>
    </aside>