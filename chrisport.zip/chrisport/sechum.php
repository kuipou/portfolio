<? 
/* Template Name: Sechum */
get_header();
get_sidebar();
 ?>
    
    <section class="main">

      
      <h1>Syndicat des Employ&eacute; du CHUM</h1>
      <section class="screenshot"><img src="<? get_bloginfo('url' ); ?>/images/sechum_500.png" alt="screen shot of Sechum"></section>
      <section class="description">
      <p>I was approached to do a makeover to the site as the older iteration seemed stucked in 1999. To ensure the site would be easy to use I chose Wordpress as it's CMS. To meet the demands of the client many custom plugins were written as well.</p>
       
       <a class="demo btn" href="http://www.sechum.org">Visit the site</a></button></aside>
        </section>
      </section>
<? get_footer(); ?>